package main

import (
	"mymodule/config"

	"github.com/gofiber/fiber/v2"
)

func main() {
	config.Database()
	config.AutoMigrate()

	app:= fiber.New()

	app.Listen(":3000")
	

	// app:=fiber.New()
}

